DROP PROCEDURE IF EXISTS pilot2.P_WebsiteActiveDeActivePilot;
CREATE PROCEDURE pilot2.`P_WebsiteActiveDeActivePilot`(IN paramfkPilotid int,in paramIsVoid bit,out ReturnValue int)
BEGIN
     update pilotmaster set isVoid = paramIsVoid where pkPilotId = paramfkPilotid;
END;

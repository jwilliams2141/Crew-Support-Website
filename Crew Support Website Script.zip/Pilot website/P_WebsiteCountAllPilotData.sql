DROP PROCEDURE IF EXISTS pilot2.P_WebsiteCountAllPilotData;
CREATE PROCEDURE pilot2.`P_WebsiteCountAllPilotData`()
BEGIN -- call P_WebsiteCountAllPilotData()
 
 
 select 
 (select count(*) from pilotmaster where fkMemberShipId = 1) as OwnerCount,
 (select count(*) from pilotmaster where fkMemberShipId = 2) as InstructorCount,
 (select count(*) from pilotmaster where fkMemberShipId = 3) as PilotCount,
 (select count(*) from pilotmaster where fkMemberShipId = 4) as FACount,
 (select count(*) from pilotmaster where fkMemberShipId = 5) as SICCount;
 
 
 select m.membershipType as MembershipType,P.* from pilotmaster p 
 left join membershipmaster m on m.pkMemberID = p.fkMemberShipId ;
 
END;



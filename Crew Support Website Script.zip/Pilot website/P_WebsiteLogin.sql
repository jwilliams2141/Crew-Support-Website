DROP PROCEDURE IF EXISTS pilot2.P_WebsiteLogin;
CREATE PROCEDURE pilot2.`P_WebsiteLogin`(IN paramUserName VARCHAR(200),IN paramPassword VARCHAR(200))
BEGIN -- call P_WebsiteLogin('CrewSupport','India@2141')
 
 
 select * from users where UserName = paramUserName and  Password =paramPassword;
 
END;

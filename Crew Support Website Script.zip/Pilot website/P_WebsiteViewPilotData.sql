DROP PROCEDURE IF EXISTS pilot2.P_WebsiteViewPilotData;
CREATE PROCEDURE pilot2.`P_WebsiteViewPilotData`(IN paramfkPilotid int)
BEGIN -- call P_WebsiteViewPilotData()
 
  select * from pilotmaster where pkPilotId = paramfkPilotid;
 
END;
